'use strict';

module.exports = require('./truffle-config');
